/*
 * If you change this file then run
 * cd src/main/java && zip react.js.zip react4j/todomvc/react4j.js
 */

goog.provide('braincheck');

/** @define {string} */
goog.define('braincheck.environment', 'production');

/** @define {string} */
goog.define('braincheck.verbose_error_messages', 'false');
/** @define {string} */
goog.define('braincheck.check_invariants', 'false');
/** @define {string} */
goog.define('braincheck.check_api_invariants', 'false');
