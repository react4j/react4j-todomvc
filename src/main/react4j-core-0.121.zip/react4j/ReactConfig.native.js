// Ensure that @defines are included so that they can specified at compile time for the closure compiler
/** @suppress {extraRequire} */
let react4j = goog.require('react4j');
